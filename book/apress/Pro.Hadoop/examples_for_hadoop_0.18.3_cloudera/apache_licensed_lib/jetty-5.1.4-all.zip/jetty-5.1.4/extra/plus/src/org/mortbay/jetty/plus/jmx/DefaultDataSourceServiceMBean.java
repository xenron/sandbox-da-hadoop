/*
 * Created on Aug 27, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package org.mortbay.jetty.plus.jmx;

import javax.management.MBeanException;


/**
 * @author janb
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class DefaultDataSourceServiceMBean extends
        AbstractDataSourceServiceMBean
{
    public DefaultDataSourceServiceMBean()
    throws MBeanException
    {}
}
