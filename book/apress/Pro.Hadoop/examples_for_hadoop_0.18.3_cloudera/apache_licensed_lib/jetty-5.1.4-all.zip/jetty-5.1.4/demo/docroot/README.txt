
This directory contains the static files for the Jetty demo.

This directory is configured to be used by the /demo context by
the $JETTY_HOME/etc/demo.xml file.

It is not a default directory for user static.  Please read the
jetty tutorial for details.


